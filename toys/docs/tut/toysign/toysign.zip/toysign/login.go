package toysign

func Login(c *controller) {
	c.View("login_form.tmpl", nil)
}

func Login2(c *controller) {
	c.Print("login2")
}
